# Creer par a.pham 29/01/2025

import pygame


class Inventaire:
    
    
    def __init__(self):
        
        
        self.objet = {}
        
        
        self.trophee = {}
        
        
        self.quete = {}
        

